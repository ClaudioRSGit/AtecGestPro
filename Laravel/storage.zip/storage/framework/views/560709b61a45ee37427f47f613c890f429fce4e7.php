<link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

<div class="container mx-auto d-flex align-items-center loginPage">
    <div class="row justify-content-center w-100 ">
        <div class="col-md-6">
            <div class="card my-auto">
                <div class="card-body">
                    <div class="d-flex flex-column align-items-center">
                        <img src="<?php echo e(asset('assets/logo.png')); ?>" alt="Logo">
                        <h5 class="mt-3"><strong> ATEC GEST PRO </strong></h5>
                    </div>
                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="username"
                                class="col-md-4 col-form-label text-md-right"><?php echo e(__('Username')); ?></label>

                            <div class="col-md-6">
                                <input id="username" type="text"
                                    class="form-control <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="username"
                                    value="<?php echo e(old('username')); ?>" required autocomplete="username" autofocus>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password"
                                class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password')); ?></label>

                            <div class="col-md-6">
                                <input id="password" type="password"
                                    class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password"
                                    required autocomplete="current-password">
                            </div>
                        </div>

                        <?php if(session('error')): ?>
                            <div class="form-group row mb-0">
                                <div class="col-md-8 offset-md-4 mb-2">
                                    <span class="text-danger font-weight-bold"><?php echo e(session('error')); ?></span>
                                </div>
                            </div>
                        <?php endif; ?>

                        <div class="form-group row mb-0">
                            <div class="col-md-8 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Login')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\kreot\source\repos\AtecGestPro2\Laravel\resources\views/login/login.blade.php ENDPATH**/ ?>