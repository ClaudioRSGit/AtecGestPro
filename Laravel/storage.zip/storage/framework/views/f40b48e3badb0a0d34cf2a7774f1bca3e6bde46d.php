

<?php $__env->startSection('content'); ?>
    <div class="w-100">



        <div class="row">
            <div class="col-8">
                <h1>Atribuir</h1>

                <div class="d-flex justify-content-between mb-3">
                    <div class="input-group mb-3" style="width: 60%;">
                        <p class="mr-3 font-weight-bold">Formando: <?php echo e($student->name); ?> </p>

                    </div>



                </div>
                <form action="<?php echo e(route('material-user.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>

                    <input type="hidden" name="user_id" value="<?php echo e($student->id); ?>">
                    <table class="table">
                        <thead>
                        <tr>
                            <th scope="col" class="h-100 d-flex justify-content-center align-items-center">
                                <input type="checkbox" id="select-all" class="h-100">
                            </th>
                            <th scope="col">Nome</th>
                            <th scope="col" style="text-align: center;">Tamanho</th>
                            <th scope="col" style="text-align: center;">Quantidade</th>
                            <th scope="col" style="text-align: center;">Data de Entrega</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $clothes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clothingItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $totalStock = $clothingItem->sizes->sum('pivot.stock');
                                $disabled = $totalStock > 0 ? '' : 'disabled';
                            ?>
                            <tr class="material-row">
                                <td>
                                    <div class="form-check d-flex justify-content-center align-items-center">
                                        <input class="form-check-input" name="selectedClothing[<?php echo e($clothingItem->id); ?>]"
                                               type="checkbox" value="<?php echo e($clothingItem->id); ?>"
                                               data-size-select="#filter<?php echo e($loop->index); ?>"
                                               id="flexCheckDefault<?php echo e($loop->index); ?>" <?php echo e($disabled); ?>>
                                    </div>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('materials.show', $clothingItem->id)); ?>"><?php echo e(isset($clothingItem->name) ? $clothingItem->name : 'N.A.'); ?></a>
                                </td>
                                <td style="text-align: center;">
                                    <input type="hidden" name="material_size_id[]" class="material-size-id-input"
                                           value="" <?php echo e($disabled); ?>>
                                    <select class="form-control size-select" id="filter<?php echo e($loop->index); ?>"
                                            name="material_size_id[<?php echo e($clothingItem->id); ?>]"
                                            data-clothing-id="<?php echo e($clothingItem->id); ?>" <?php echo e($disabled); ?>>

                                        <?php
                                            $hasStock = false;
                                        ?>

                                        <?php $__currentLoopData = $clothingItem->sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($size->pivot->stock > 0): ?>
                                                <?php
                                                    $hasStock = true;
                                                ?>
                                                <option value="<?php echo e($size->id); ?>" data-stock="<?php echo e($size->pivot->stock); ?>">
                                                    <?php echo e($size->size); ?> (<?php echo e($size->pivot->stock); ?>)
                                                </option>
                                            <?php else: ?>
                                                <option disabled><?php echo e($size->size); ?> (Não existe stock)</option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <?php if(!$hasStock): ?>
                                            <option disabled selected>Não existe nenhum tamanho com stock</option>
                                        <?php endif; ?>

                                    </select>
                                </td>
                                <td class="pl-4">
                                    <input type="number" class="form-control quantity-input"
                                           id="quantity<?php echo e($loop->index); ?>"
                                           name="quantity[<?php echo e($clothingItem->id); ?>]" value="1" min="1"
                                           style="width: 60px; text-align: center;" <?php echo e($disabled); ?>>
                                </td>
                                <td style="text-align: center;">
                                    <input type="date" class="form-control"
                                           name="delivery_date[<?php echo e($clothingItem->id); ?>]"
                                           value="<?php echo e(date('Y-m-d')); ?>" <?php echo e($disabled); ?>>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>


                    <div class="row mb-3 ">
                        <div class="col-4">
                            <textarea placeholder="Observações" class="form-control" name="additionalNotes"
                                      id="textarea" aria-label="With textarea"></textarea>
                        </div>
                        <div class="col-2 d-flex ">
                            <label for="delivered" style="margin: auto;" class=" ">Entrega Completa</label>
                            <input type="hidden" name="delivered_all" value="0">
                            <input type="checkbox" class="form-control" id="delivered" name="delivered_all" value="1"
                                   style="width: 15px;text-align: left;margin: auto "
                                <?php echo e(old('delivered_all', $student->materialUsers()->where('delivered_all', 1)->exists()) ? 'checked' : ''); ?>>
                        </div>

                        <div class="col-6 d-flex justify-content-end" style="margin: auto">
                            <button class="btn btn-primary mx-3" type="submit">
                                <svg xmlns="http://www.w3.org/2000/svg" width="35" height="25" fill="currentColor"
                                     class="bi bi-floppy" viewBox="0 0 16 16">
                                    <path d="M11 2H9v3h2z"/>
                                    <path
                                        d="M1.5 0h11.586a1.5 1.5 0 0 1 1.06.44l1.415 1.414A1.5 1.5 0 0 1 16 2.914V14.5a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 0 14.5v-13A1.5 1.5 0 0 1 1.5 0M1 1.5v13a.5.5 0 0 0 .5.5H2v-4.5A1.5 1.5 0 0 1 3.5 9h9a1.5 1.5 0 0 1 1.5 1.5V15h.5a.5.5 0 0 0 .5-.5V2.914a.5.5 0 0 0-.146-.353l-1.415-1.415A.5.5 0 0 0 13.086 1H13v4.5A1.5 1.5 0 0 1 11.5 7h-7A1.5 1.5 0 0 1 3 5.5V1H1.5a.5.5 0 0 0-.5.5m3 4a.5.5 0 0 0 .5.5h7a.5.5 0 0 0 .5-.5V1H4zM3 15h10v-4.5a.5.5 0 0 0-.5-.5h-9a.5.5 0 0 0-.5.5z"/>
                                    <path
                                        d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708"/>
                                </svg>
                                Guardar
                            </button>
                            <button class="btn btn-danger" type="button"
                                    onclick="window.location.href='<?php echo e(url()->previous()); ?>'">
                                <svg xmlns="http://www.w3.org/2000/svg" width="35" height="25" fill="currentColor"
                                     class="bi bi-x-square" viewBox="0 0 16 16">
                                    <path
                                        d="M14 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1zM2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2z"/>
                                    <path
                                        d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708"/>
                                </svg>
                                Fechar
                            </button>
                        </div>
                    </div>

                </form>
            </div>
            <div class="col-4 card badge-secondary">
                <h3 class="pt-2">Materiais atribuídos</h3>
                <hr>
                <?php $__empty_1 = true; $__currentLoopData = $assignedClothes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <ul>
                        <li><?php echo e($item->material->name); ?> <?php echo e($item->size->size); ?> - <?php echo e($item->quantity); ?> uni</li>
                    </ul>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>Nenhuma farda entregue ao utilizador</p>
                <?php endif; ?>
            </div>
        </div>


        <?php echo e($clothes->links()); ?>



    </div>



    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const selectAllCheckbox = document.getElementById('select-all');
            const checkboxes = document.querySelectorAll('.form-check-input');

            $(document).ready(function () {
                $('.material-row .size-select').each(function (index, select) {
                    var quantityInput = $('.material-row .quantity-input').eq(index);
                    $(select).change(function () {
                        var selectedOption = $(this).children("option:selected");
                        var stock = parseInt(selectedOption.data('stock'));
                        quantityInput.attr('max', stock);

                        if (parseInt(quantityInput.val()) > stock) {
                            quantityInput.val(stock);
                        }
                    }).trigger('change');

                    quantityInput.on('input', function () {
                        var max = parseInt($(this).attr('max'));
                        if (parseInt($(this).val()) > max) {
                            $(this).val(max);
                        }
                    });
                });
            });

            function updateFormData() {
                const formData = new FormData(document.querySelector('form'));

                document.querySelectorAll('.form-check-input:checked').forEach(function (checkbox) {
                    const clothingId = checkbox.value;
                    const selectElement = document.querySelector(`.size-select[data-clothing-id="${clothingId}"]`);
                    const selectedOption = selectElement.options[selectElement.selectedIndex];
                    const materialSizeId = selectedOption.value;

                    formData.set(`material_size_id[${clothingId}]`, materialSizeId);
                });

                document.querySelectorAll('.material-row .size-select:not(:checked)').forEach(function (select) {
                    const clothingId = select.getAttribute('data-clothing-id');
                    formData.delete(`material_size_id[${clothingId}]`);
                });


            }


            document.querySelector('form').addEventListener('submit', function (e) {
                updateFormData();
            });


            selectAllCheckbox.addEventListener('change', function () {
                checkboxes.forEach(checkbox => {
                    checkbox.checked = selectAllCheckbox.checked;
                });
            });

            checkboxes.forEach(checkbox => {
                checkbox.addEventListener('change', function () {
                    selectAllCheckbox.checked = checkboxes.length === document.querySelectorAll(
                        'input[name="selectedClothing[]"]:checked').length;
                });
            });


            $(document).ready(function () {
                $('form').on('keydown', function (e) {
                    if (e.keyCode == 13) {
                        e.preventDefault();
                        return false;
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kreot\source\repos\AtecGestPro2\Laravel\resources\views/material-user/create.blade.php ENDPATH**/ ?>