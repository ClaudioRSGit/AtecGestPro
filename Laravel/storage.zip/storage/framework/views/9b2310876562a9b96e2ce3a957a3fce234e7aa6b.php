<!doctype html>
<html lang="en">
<head>

    <title>Atec Gest Pro Email</title>
</head>
<body>
<h1><?php echo e($details['title']); ?></h1>
<p><?php echo e($details['body']); ?></p>
</body>
</html>
<?php /**PATH C:\Users\kreot\source\repos\AtecGestPro2\Laravel\resources\views/mail/notification-email.blade.php ENDPATH**/ ?>