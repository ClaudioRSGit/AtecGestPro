

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Ticket #<?php echo e($ticket->id); ?></h1>

    <div class="row">
        <div class="col-md-9">
            <div class="mb-3">
                <label for="title" class="form-label">Título:</label>
                <input type="text" class="form-control" id="title" value="<?php echo e($ticket->title); ?>" disabled>
            </div>

            <div class="mb-3">
                <label for="description" class="form-label">Descrição:</label>
                <textarea class="form-control" id="description" disabled><?php echo e($ticket->description); ?></textarea>
            </div>

            <div class="mb-2">
                <p>Criado em: <?php echo e($ticket->created_at); ?></p>
            </div>

            <div class="mb-3">
                <label for="attachment" class="form-label">Anexo:</label>
                <input type="text" class="form-control" id="attachment" value="<?php echo e($ticket->attachment); ?>" disabled style="border-radius: 5px;">
                <?php if($ticket->attachment): ?>
                    <a href="<?php echo e(asset('storage/' . $ticket->attachment)); ?>" target="_blank">Ver Anexo</a>
                <?php endif; ?>
            </div>

            <div class="mb-3">
                <form action="<?php echo e(route('comments.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="ticket_id" value="<?php echo e($ticket->id); ?>">

                    <div class="mb-3">
                        <label for="new-comment" class="form-label">Adicionar Comentário:</label>
                        <textarea class="form-control" id="new-comment" name="comment" required></textarea>
                        <button type="submit" class="btn btn-primary mt-2">Enviar Comentário</button>
                    </div>
                </form>

                <div class="mb-3">
                    <label for="comments" class="form-label">Comentários:</label>
                    <?php if($ticket->comments->isNotEmpty()): ?>
                        <?php $__currentLoopData = $ticket->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card mb-2">
                                <div class="card-body d-flex justify-content-between">
                                    <div>
                                        <label class="card-text font-weight-bold">
                                            <?php echo e($comment->user->name); ?>:
                                        </label>
                                        <?php echo e($comment->description); ?>

                                    </div>
                                    <div>
                                        <p class="card-text">
                                            <?php echo e($comment->created_at); ?>

                                        </p>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <p>Não existem comentários para este ticket.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="mb-3">
                <label for="status" class="form-label">Estado:</label>
                <input type="text" class="form-control" value="<?php echo e($ticket->ticketStatus->description ?? 'N/A'); ?>" disabled>
            </div>

            <div class="mb-3">
                <label for="technician" class="form-label">Técnico:</label>
                <input type="text" class="form-control" value="<?php echo e($technician->name ?? 'N/A'); ?>" disabled>
            </div>

            <div class="mb-3">
                <label for="priority" class="form-label">Prioridade:</label>
                <input type="text" class="form-control" value="<?php echo e($ticket->ticketPriority->description ?? 'N/A'); ?>" disabled>
            </div>

            <div class="mb-3">
                <label for="category" class="form-label">Categoria:</label>
                <input type="text" class="form-control" value="<?php echo e($ticket->ticketCategory->description ?? 'N/A'); ?>" disabled>
            </div>

            <div class="mb-3">
                <label>Data Limite:</label>
                <input type="text" class="form-control" value="<?php echo e($ticket->dueByDate ?? 'N/A'); ?>" disabled>
            </div>

            <div class="mb-5">
                <label>Histórico do Utilizador:</label>
                <ul>
                    <?php $__currentLoopData = $userTickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userTicketId): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(route('tickets.show', $userTicketId)); ?>">Ticket #<?php echo e($userTicketId); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>


            <div class="mb-5">
                <div class="mb-5">
                    <label>Histórico do Ticket:</label>
                    <a href="<?php echo e(route('ticket-histories.show', $ticket->id)); ?>">Ver Histórico</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kreot\source\repos\AtecGestPro2\Laravel\resources\views/tickets/show.blade.php ENDPATH**/ ?>