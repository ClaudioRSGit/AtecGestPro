

<?php $__env->startSection('content'); ?>
    <div class="w-100">
        <h1>Criar Turma</h1>

        <form method="post" action="<?php echo e(route('course-classes.store')); ?>" id="createCourseClassForm" class=" mb-3">
            <?php echo csrf_field(); ?>

            <div class="row mb-3">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="description">Descrição:</label>
                        <input type="text" class="form-control" id="description" name="description">

                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="course_id">Curso:</label>
                        <select class="form-control" id="course_id" name="course_id" required>

                            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($course->id); ?>"><?php echo e($course->description); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                        <?php $__errorArgs = ['course_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                </div>
            </div>


            <div class="row">
                <h3 class="my-3">Atribuir alunos à turma</h3>
                <div class="d-flex justify-content-between w-100">
                    <div class="form-group mr-3 w-25 search-container">
                        <input type="text" id="search" class="form-control w-100" placeholder="Pesquisar Aluno">
                    </div>
                    <div class="form-group w-25">
                        <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary w-100">
                            <img src="<?php echo e(asset('assets/new.svg')); ?>">
                            Novo Aluno
                        </a>
                    </div>
                </div>
                <div class="scrollable w-100">
                    <table class="table" id="studentsTable">
                        <thead>
                        <tr>
                            <th><input type="checkbox" id="select-all"></th>
                            <th>Nome</th>
                            <th>Username</th>
                            <th>Email</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><input type="checkbox" name="selected_students[]" value="<?php echo e($student->id); ?>"></td>
                                <td><?php echo e($student->name); ?></td>
                                <td><?php echo e($student->username); ?></td>
                                <td><?php echo e($student->email); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>


            <button type="submit" class="btn btn-primary" name="noImport" id="criarTurmaBtn">Criar Turma</button>
            <button type="submit" class="btn btn-primary" name="import">Criar Turma e importar alunos a partir de
                Excel
            </button>
            <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary">Cancelar</a>
        </form>

    </div>

    <style>

        .scrollable {
            height: 300px;
            overflow-y: scroll;
        }
    </style>

    <script>
        $(document).ready(function () {
            $("#select-all").click(function () {
                $("input[name='selected_students[]']").prop('checked', $(this).prop('checked'));
            });

            $("#criarTurmaBtn").click(function () {
                document.getElementById('createCourseClassForm').submit();
            });

            $("#search").on("keyup", function () {
                let value = $(this).val().toLowerCase();
                $("#studentsTable tbody tr").filter(function () {
                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kreot\source\repos\AtecGestPro2\Laravel\resources\views/course-classes/create.blade.php ENDPATH**/ ?>