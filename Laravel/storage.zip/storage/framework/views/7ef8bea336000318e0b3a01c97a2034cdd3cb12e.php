

<?php $__env->startSection('content'); ?>
    <div class="container">

        <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        <h1>Criar Novo Utilizador</h1>

        <form method="post" action="<?php echo e(route('users.store')); ?>" enctype="multipart/form-data" id="userForm">
            <?php echo csrf_field(); ?>
            <?php echo method_field('POST'); ?>

            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="name" class="form-label">Nome do Utilizador:</label>
                        <input type="text" class="form-control" id="name" name="name" value="<?php echo e(old('name')); ?>">

                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label for="username" class="form-label">Username:</label>
                        <input type="text" class="form-control" id="username" name="username" value="<?php echo e(old('username')); ?>">

                        <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label for="email" class="form-label">Email:</label>
                        <input type="text" class="form-control" id="email" name="email" value="<?php echo e(old('email')); ?>">

                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label for="contact" class="form-label">Contacto:</label>
                        <input type="text" class="form-control" id="contact" name="contact" value="<?php echo e(old('contact')); ?>">

                        <?php $__errorArgs = ['contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label for="password" class="form-label">Password:</label>
                        <input type="password" class="form-control" id="password" name="password" value="<?php echo e(old('password')); ?>">

                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="col-md-6 d-flex flex-column">
                    <div class="mb-3">
                        <label for="role_id" class="form-label">Função:</label>
                        <select class="form-control" id="role_id" name="role_id" onchange="toggleCourseClassDiv()">
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($role->id); ?>" <?php echo e($role->description); ?>>
                                    <?php echo e($role->description); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <input type="hidden" name="isStudent" id="isStudent" value="<?php echo e(old('role_id') == 3 ? 1 : 0); ?>">


                    <div class="mb-3" id="labelCourseClass" style="display: none;">
                        <label for="course_class_id" class="form-label">Turma:</label>
                        <select class="form-select" id="course_class_id" name="course_class_id" onchange="updateCourseDescription(this)">
                            <?php $__currentLoopData = $courseClasses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option
                                    value="<?php echo e($class->id); ?>"
                                    data-course-description="<?php echo e($class->course->description); ?>"
                                    <?php echo e(old('course_class_id') == $class->id || (isset($user) && $user->course_class_id == $class->id) ? 'selected' : ''); ?>>
                                    <?php echo e($class->description); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>





                    <div class="mb-3">
                        <label for="isActive" class="form-label">Estado:</label>
                        <select class="form-select" id="isActive" name="isActive">
                            <option value="1">Ativo</option>
                            <option value="0">Desativado</option>
                        </select>
                    </div>
                    <div class="buttons d-flex justify-content-start align-items-center">
                        <button type="submit" class="btn btn-primary">Criar Utilizador</button>
                        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary">Cancelar</a>
                    </div>
                </div>


            </div>
        </form>
    </div>

    <script>
        function toggleCourseClassDiv() {
            const selectedRole = $("#role_id").val();
            const isStudentValue = selectedRole === "3" ? 1 : 0;

            $("#isStudent").val(isStudentValue);

            if (selectedRole === "3") {
                $("#labelCourseClass").show();
                $("#password").closest(".mb-3").hide();
            } else {
                $("#labelCourseClass").hide();
                $("#password").closest(".mb-3").show();
            }
        }

        $(document).ready(function() {
            toggleCourseClassDiv();
        });
    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kreot\source\repos\AtecGestPro2\Laravel\resources\views/users/create.blade.php ENDPATH**/ ?>