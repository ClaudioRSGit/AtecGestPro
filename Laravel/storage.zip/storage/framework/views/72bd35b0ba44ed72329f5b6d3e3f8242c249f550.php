

<?php $__env->startSection('content'); ?>
    <div class="container">

        <?php if(session('success')): ?>
            <div class="alert alert-success" id="success-alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <h1>Detalhes do Curso</h1>

        <div>
            <div class="w-50">
                <div class="mb-3">
                    <label for="code" class="form-label">Nome do Curso:</label>
                    <input type="text" class="form-control" id="code" name="code" value="<?php echo e($course->code); ?>"
                        disabled>
                </div>

                <div class="mb-3">
                    <label for="description" class="form-label">Descrição:</label>
                    <input type="text" class="form-control" id="description" name="description"
                        value="<?php echo e($course->description); ?>" disabled>
                </div>

                <div class="form-group">
                    <a href="<?php echo e(route('courses.edit', $course->id)); ?>" class="btn btn-primary">Editar</a>
                    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary">Cancelar</a>
                </div>
            </div>
        </div>
    </div>

    <script>
         setTimeout(function() {
            $("#success-alert").fadeTo(500, 0).slideUp(500, function() {
                $(this).remove();
            });
        }, 2000);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kreot\source\repos\AtecGestPro2\Laravel\resources\views/courses/show.blade.php ENDPATH**/ ?>