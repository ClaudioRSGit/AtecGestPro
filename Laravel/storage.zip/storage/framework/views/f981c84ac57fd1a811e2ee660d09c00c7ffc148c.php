

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if(session('success')): ?>
            <div class="alert alert-success" id="success-alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        

        <ul class="nav nav-tabs" id="myTab" role="tablist">
            <li class="nav-item">
                <a class="nav-link active" id="all-tickets-tab" data-toggle="tab" href="#allTickets" role="tab"
                   aria-controls="allTickets" aria-selected="true">Todos os tickets</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="waiting-queue-tab" data-toggle="tab" href="#waitingQueue" role="tab"
                   aria-controls="waitingQueue" aria-selected="false">Fila de Espera</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="recycling-tab" data-toggle="tab" href="#recycling" role="tab"
                   aria-controls="recycling" aria-selected="false">Reciclagem</a>
            </li>
        </ul>

        <div>
            <div class="tab-content" id="myTabContent">


                <div class="tab-pane fade show active" id="allTickets" role="tabpanel"
                     aria-labelledby="all-tickets-tab">
                    <div class="d-flex justify-content-between my-3">

                        <form action="<?php echo e(route('tickets.index')); ?>" method="get" id="ticketSearchForm">
                            <div class="input-group pr-2">
                                <div class="search-container">
                                    <input type="text" class="form-control" id="ticketSearch" name="ticketSearch"
                                           value="<?php echo e(request('ticketSearch')); ?>"
                                           placeholder="<?php echo e(request('ticketSearch') ? request('ticketSearch') : 'Pesquisar ticket...'); ?>">
                                </div>
                                <div class="input-group-append">
                                    <button type="submit" class="btn btn-outline-secondary">
                                        Procurar
                                    </button>
                                </div>
                            </div>

                        </form>
                        <div class="buttons">
                            <form id="filterCategoryForm" action="<?php echo e(route('tickets.index')); ?>" method="GET">
                                <select class="form-control w-auto" id="filterCategory" name="filterCategory"
                                        onchange="submitCategoryForm()">
                                    <option value="" <?php echo e($filterCategory === '' ? 'selected' : ''); ?>>Todas as categorias
                                    </option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>"
                                            <?php echo e((int) $filterCategory === $category->id ? 'selected' : ''); ?>><?php echo e($category->description); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>
                            </form>

                            <form id="filterStatusForm" action="<?php echo e(route('tickets.index')); ?>" method="GET">
                                <select class="form-control w-auto" id="filterStatus" name="filterStatus"
                                        onchange="submitStatusForm()">
                                    <option value="" <?php echo e($filterStatus === '' ? 'selected' : ''); ?>>Todos os estados
                                    </option>
                                    <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($status->id); ?>"
                                            <?php echo e((int) $filterStatus === $status->id ? 'selected' : ''); ?>><?php echo e($status->description); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </form>

                            <form id="filterPriorityForm" action="<?php echo e(route('tickets.index')); ?>" method="GET">
                                <select class="form-control w-auto" id="filterPriority" name="filterPriority"
                                        onchange="submitPriorityForm()">
                                    <option value="" <?php echo e($filterPriority === '' ? 'selected' : ''); ?>>Todas as prioridades
                                    </option>
                                    <?php $__currentLoopData = $priorities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $priority): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($priority->id); ?>"
                                            <?php echo e((int) $filterPriority === $priority->id ? 'selected' : ''); ?>>
                                            <?php echo e($priority->description); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </form>


                            <a href="<?php echo e(route('tickets.create')); ?>" class="btn btn-primary d-flex">
                                <img src="<?php echo e(asset('assets/new.svg')); ?>">
                                <p class="novoTicket d-flex align-items-center">Novo Ticket</p>
                            </a>


                        </div>
                    </div>

                    <?php if(count($tickets) === 0): ?>
                        <div>
                            <img src="<?php echo e(asset('assets/noTickets.png')); ?>" class="noTicket">
                        </div>

                    <?php else: ?>
                        <?php
                            $currentSort = request('sort');
                            $currentDirection = request('direction', 'asc');
                            $newDirection = $currentDirection == 'asc' ? 'desc' : 'asc';
                        ?>
                        <table class="table bg-white rounded-top">
                            <thead>
                            <tr>
                                <th scope="col">
                                    <a href="<?php echo e(route('tickets.index', ['sort' => 'number', 'direction' => $currentSort === 'number' ? $newDirection : 'asc'])); ?>">
                                        Número
                                    </a>
                                </th>
                                <th scope="col">
                                    <a href="<?php echo e(route('tickets.index', ['sort' => 'title', 'direction' => $currentSort === 'title' ? $newDirection : 'asc'])); ?>">
                                        Título
                                    </a>
                                </th>
                                <th scope="col">
                                    <a href="<?php echo e(route('tickets.index', ['sort' => 'user', 'direction' => $currentSort === 'user' ? $newDirection : 'asc'])); ?>">
                                        Utilizador
                                    </a>
                                </th>
                                <th scope="col">
                                    <a href="<?php echo e(route('tickets.index', ['sort' => 'technician', 'direction' => $currentSort === 'technician' ? $newDirection : 'asc'])); ?>">
                                        Técnico
                                    </a>
                                </th>
                                <th scope="col">Estado</th>
                                <th scope="col">Data de Abertura</th>
                                <th scope="col">Data de Vencimento</th>
                                <th scope="col">Ações</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr class="filler"></tr>
                            <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="customTableStyling" id="heading<?php echo e($ticket->id); ?>"
                                    onclick="location.href='<?php echo e(route('tickets.show', $ticket->id)); ?>'">

                                    <td class="pl-4">#<?php echo e($ticket->id ? $ticket->id : 'N.A.'); ?></td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                    <span class="mr-2"
                                          style="height: 15px; width: 15px; background-color: <?php echo e($ticket->ticketPriority->id == 1 ? 'green' : ($ticket->ticketPriority->id == 2 ? 'green' : ($ticket->ticketPriority->id == 3 ? 'yellow' : ($ticket->ticketPriority->id == 4 ? 'orange' : 'red')))); ?>; border-radius: 50%; display: inline-block; opacity: 0.5;"></span>
                                            <p><?php echo e($ticket->title ? $ticket->title : 'N.A.'); ?></p>
                                        </div>
                                    </td>
                                    <td><?php echo e($ticket->requester->name ? $ticket->requester->name : 'N.A.'); ?></td>
                                    <td>
                                        <?php $__currentLoopData = $ticket->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($user->name); ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td><?php echo e($ticket->ticketStatus->description ? $ticket->ticketStatus->description : 'N.A.'); ?></td>
                                    <td><?php echo e($ticket->created_at ? $ticket->created_at->format('d-m-Y') : 'N.A.'); ?></td>
                                    <td><?php echo e($ticket->dueByDate ? \Carbon\Carbon::parse($ticket->dueByDate)->format('d-m-Y') : 'N.A.'); ?>

                                    </td>
                                    <td class="editDelete">
                                        <div>
                                            <a href="<?php echo e(route('tickets.edit', $ticket->id)); ?>">
                                                <svg xmlns="http://www.w3.org/2000/svg" height="16" width="16"
                                                     viewBox="0 0 512 512">
                                                    <path fill="#116fdc"
                                                          d="M471.6 21.7c-21.9-21.9-57.3-21.9-79.2 0L362.3 51.7l97.9 97.9 30.1-30.1c21.9-21.9 21.9-57.3 0-79.2L471.6 21.7zm-299.2 220c-6.1 6.1-10.8 13.6-13.5 21.9l-29.6 88.8c-2.9 8.6-.6 18.1 5.8 24.6s15.9 8.7 24.6 5.8l88.8-29.6c8.2-2.7 15.7-7.4 21.9-13.5L437.7 172.3 339.7 74.3 172.4 241.7zM96 64C43 64 0 107 0 160V416c0 53 43 96 96 96H352c53 0 96-43 96-96V320c0-17.7-14.3-32-32-32s-32 14.3-32 32v96c0 17.7-14.3 32-32 32H96c-17.7 0-32-14.3-32-32V160c0-17.7 14.3-32 32-32h96c17.7 0 32-14.3 32-32s-14.3-32-32-32H96z"/>
                                                </svg>
                                            </a>
                                        </div>
                                        <div>
                                            <form method="post" action="<?php echo e(route('tickets.destroy', $ticket->id)); ?>"
                                                  style="display:inline;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <button type="submit"
                                                        onclick="return confirm('Tem certeza que deseja apagar?')"
                                                        style="border: none; background: none; padding: 0; margin: 0; cursor: pointer;">
                                                    <svg xmlns="http://www.w3.org/2000/svg" height="16" width="14"
                                                         viewBox="0 0 448 512">
                                                        <path fill="#116fdc"
                                                              d="M135.2 17.7C140.6 6.8 151.7 0 163.8 0H284.2c12.1 0 23.2 6.8 28.6 17.7L320 32h96c17.7 0 32 14.3 32 32s-14.3 32-32 32H32C14.3 96 0 81.7 0 64S14.3 32 32 32h96l7.2-14.3zM32 128H416V448c0 35.3-28.7 64-64 64H96c-35.3 0-64-28.7-64-64V128zm96 64c-8.8 0-16 7.2-16 16V432c0 8.8 7.2 16 16 16s16-7.2 16-16V208c0-8.8-7.2-16-16-16zm96 0c-8.8 0-16 7.2-16 16V432c0 8.8 7.2 16 16 16s16-7.2 16-16V208c0-8.8-7.2-16-16-16zm96 0c-8.8 0-16 7.2-16 16V432c0 8.8 7.2 16 16 16s16-7.2 16-16V208c0-8.8-7.2-16-16-16z"/>
                                                    </svg>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                <tr class="filler"></tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                    <?php echo e($tickets->appends(request()->input())->links()); ?>

                </div>

                <div class="tab-pane fade" id="waitingQueue" role="tabpanel" aria-labelledby="waiting-queue-tab">
                    <?php if(count($tickets) === 0): ?>
                        <div>
                            <img src="<?php echo e(asset('assets/noTickets.png')); ?>" class="noTicket">
                        </div>

                    <?php else: ?>
                        <table class="table bg-white rounded-top">
                            <thead>
                            <tr>
                                <th scope="col">Número</th>
                                <th scope="col">Título</th>
                                <th scope="col">Utilizador</th>
                                <th scope="col">Técnico</th>
                                <th scope="col">Estado</th>
                                <th scope="col">Data de Abertura</th>
                                <th scope="col">Ações</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr class="filler"></tr>
                            <?php $__currentLoopData = $waitingQueueTickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="customTableStyling">
                                    <td class="pl-4">#<?php echo e($ticket->id); ?></td>
                                    <td>
                                        <div class="d-flex align-items-center">
                            <span class="mr-2"
                                  style="height: 15px; width: 15px; background-color: <?php echo e($ticket->ticketPriority->id == 1 ? 'green' : ($ticket->ticketPriority->id == 2 ? 'green' : ($ticket->ticketPriority->id == 3 ? 'yellow' : ($ticket->ticketPriority->id == 4 ? 'orange' : 'red')))); ?>; border-radius: 50%; display: inline-block; opacity: 0.5;"></span>
                                            <p><?php echo e($ticket->title ? $ticket->title : 'N.A.'); ?></p>
                                        </div>
                                    </td>
                                    <td><?php echo e($ticket->requester->name); ?></td>
                                    <td>
                                        <?php $__currentLoopData = $ticket->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($user->name); ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td><?php echo e($ticket->ticketStatus->description); ?></td>
                                    <td><?php echo e($ticket->created_at->format('d-m-Y')); ?></td>
                                    <td class="editDelete">
                                        <div class="w-50">
                                            <a href="<?php echo e(route('tickets.edit', $ticket->id)); ?>">
                                                <svg xmlns="http://www.w3.org/2000/svg" height="16" width="16"
                                                     viewBox="0 0 512 512">
                                                    <path fill="#116fdc"
                                                          d="M471.6 21.7c-21.9-21.9-57.3-21.9-79.2 0L362.3 51.7l97.9 97.9 30.1-30.1c21.9-21.9 21.9-57.3 0-79.2L471.6 21.7zm-299.2 220c-6.1 6.1-10.8 13.6-13.5 21.9l-29.6 88.8c-2.9 8.6-.6 18.1 5.8 24.6s15.9 8.7 24.6 5.8l88.8-29.6c8.2-2.7 15.7-7.4 21.9-13.5L437.7 172.3 339.7 74.3 172.4 241.7zM96 64C43 64 0 107 0 160V416c0 53 43 96 96 96H352c53 0 96-43 96-96V320c0-17.7-14.3-32-32-32s-32 14.3-32 32v96c0 17.7-14.3 32-32 32H96c-17.7 0-32-14.3-32-32V160c0-17.7 14.3-32 32-32h96c17.7 0 32-14.3 32-32s-14.3-32-32-32H96z"/>
                                                </svg>
                                            </a>
                                        </div>
                                        <div class="w-50">
                                            <form method="post" action="<?php echo e(route('tickets.destroy', $ticket->id)); ?>"
                                                  style="display:inline;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <button type="submit"
                                                        onclick="return confirm('Tem certeza que deseja apagar?')"
                                                        style="border: none; background: none; padding: 0; margin: 0; cursor: pointer;">
                                                    <svg xmlns="http://www.w3.org/2000/svg" height="16" width="14"
                                                         viewBox="0 0 448 512">
                                                        <path fill="#116fdc"
                                                              d="M135.2 17.7C140.6 6.8 151.7 0 163.8 0H284.2c12.1 0 23.2 6.8 28.6 17.7L320 32h96c17.7 0 32 14.3 32 32s-14.3 32-32 32H32C14.3 96 0 81.7 0 64S14.3 32 32 32h96l7.2-14.3zM32 128H416V448c0 35.3-28.7 64-64 64H96c-35.3 0-64-28.7-64-64V128zm96 64c-8.8 0-16 7.2-16 16V432c0 8.8 7.2 16 16 16s16-7.2 16-16V208c0-8.8-7.2-16-16-16zm96 0c-8.8 0-16 7.2-16 16V432c0 8.8 7.2 16 16 16s16-7.2 16-16V208c0-8.8-7.2-16-16-16zm96 0c-8.8 0-16 7.2-16 16V432c0 8.8 7.2 16 16 16s16-7.2 16-16V208c0-8.8-7.2-16-16-16z"/>
                                                    </svg>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                <tr class="filler"></tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                    <?php echo e($waitingQueueTickets->appends(request()->input())->links()); ?>

                </div>


                <div class="tab-pane fade" id="recycling" role="tabpanel" aria-labelledby="recycling-tab">
                    <table class="table table-hover">
                        <thead>
                        <tr>
                            <th scope="col">Número</th>
                            <th scope="col">Título</th>
                            <th scope="col">Utilizador</th>
                            <th scope="col">Técnico</th>
                            <th scope="col">Estado</th>
                            <th scope="col">Data de Abertura</th>
                            <th scope="col">Restaurar</th>
                            <th scope="col">Apagar</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $recycledTickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="customTableStyling">
                                <td class="pl-4">#<?php echo e($ticket->id); ?></td>
                                <td class="d-flex align-items-center">
                        <span class="mr-2"
                              style="height: 15px; width: 15px; background-color: <?php echo e($ticket->ticketPriority->id == 1 ? 'green' : ($ticket->ticketPriority->id == 2 ? 'green' : ($ticket->ticketPriority->id == 3 ? 'yellow' : ($ticket->ticketPriority->id == 4 ? 'orange' : 'red')))); ?>; border-radius: 50%; display: inline-block; opacity: 0.5;"></span>
                                    <p><?php echo e($ticket->title ? $ticket->title : 'N.A.'); ?></p>
                                </td>
                                <td><?php echo e($ticket->requester->name); ?></td>
                                <td>
                                    <?php $__currentLoopData = $ticket->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($user->name); ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td><?php echo e($ticket->ticketStatus->description); ?></td>
                                <td><?php echo e($ticket->created_at->format('d-m-Y')); ?></td>
                                <td class="pl-4">
                                    <div class="restore w-100 h-100 d-flex align-items-center">
                                        <a href="<?php echo e(route('tickets.restore', $ticket->id)); ?>">
                                            <img src="<?php echo e(asset('assets/restore.svg')); ?>">
                                        </a>
                                    </div>
                                </td>
                                <td class="pl-4">
                                    <div class="delete w-100 h-100 d-flex align-items-center">
                                        <form action="<?php echo e(route('tickets.forceDelete', $ticket->id)); ?>" method="POST"
                                              style="display: inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit"
                                                    onclick="return confirm('Tem a certeza que deseja apagar permanentemente?')"
                                                    style="border: none; background: none; padding: 0;">
                                                <img src="<?php echo e(asset('assets/permaDelete.svg')); ?>" alt="Delete">
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <tr class="filler"></tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($recycledTickets->appends(request()->input())->links()); ?>

                </div>

            </div>


        </div>

        <style>
            thead th {
                border-top: none !important;
            }

            .noTicket {
                margin-top: 100px !important;
                width: 20%;
                height: auto;
                margin: 0 auto;
                display: block;
                opacity: 0.5;
            }

            @media (max-width: 1080px) {
                .noTicket {
                    width: 50%;
                }
            }
        </style>

        <script>
            function submitCategoryForm() {

                document.getElementById("filterCategoryForm").submit();

            }

            function submitStatusForm() {

                document.getElementById("filterStatusForm").submit();

            }

            function submitPriorityForm() {

                document.getElementById("filterPriorityForm").submit();

            }

            window.setTimeout(function () {
                $("#success-alert").fadeTo(500, 0).slideUp(500, function () {
                    $(this).remove();
                });
            }, 2000);
        </script>

        <script>
            $(function () {
                $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
                    localStorage.setItem('lastTab', $(this).attr('href'));
                });

                let lastTab = localStorage.getItem('lastTab');
                if (lastTab) {
                    $('[href="' + lastTab + '"]').tab('show');
                }
            });
        </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kreot\source\repos\AtecGestPro2\Laravel\resources\views/tickets/index.blade.php ENDPATH**/ ?>