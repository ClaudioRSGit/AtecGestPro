<!DOCTYPE html>
<html>
<head>
    <title>Mail from Laravel</title>
</head>
<body>
    <h1>Olá <?php echo e($ticket->requester->name); ?>,</h1>
    <p>O ticket #<?php echo e($ticket->id); ?>, com o título <?php echo e($ticket->title); ?> foi criado com sucesso.</p>
    <p>Descrição</p>
    <p><?php echo e($ticket->description); ?></p>

    <p>Pode consultar o seu ticket na App Atec Gest Pro</p>
    <p>Atenciosamente</p>
    <p>Equipa Atec Gest Pro</p>
</body>
</html>
<?php /**PATH C:\Users\kreot\source\repos\AtecGestPro2\Laravel\resources\views/emails/ticketEmail.blade.php ENDPATH**/ ?>