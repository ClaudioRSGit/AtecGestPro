

<?php $__env->startSection('content'); ?>
    <div>
        <h1>Historico de Ticket: <?php echo e($ticket->id); ?></h1>

        <div>
            <?php $__currentLoopData = $ticketHistories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <h5><?php echo e($history->action->description); ?> - <?php echo e($history->created_at); ?></h5>

                <p><?php echo nl2br(str_replace('.', ".\n", e($history->ticket_info))); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kreot\source\repos\AtecGestPro2\Laravel\resources\views/ticket-histories/show.blade.php ENDPATH**/ ?>