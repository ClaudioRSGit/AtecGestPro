<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link mb-2 btn btn-light" onclick="toggleSidebar()">
                <img src="https://cdn.icon-icons.com/icons2/2518/PNG/512/menu_icon_151204.png" alt="Menu"
                    style="width: 25px; height: 25px;">
            </a>
        </li>
    </ul>
    <h5 class="ml-2">Bem vindo, <?php echo e(Auth::user()->name); ?>!</h5>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">

        <ul class="navbar-nav ml-auto">
            <li class="nav-item dropdown">

                <a class="nav-link" href="#" id="notificacoesDropdown" role="button" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                <img src="https://static.vecteezy.com/system/resources/previews/010/366/202/original/bell-icon-transparent-notification-free-png.png"
                alt="Sininho" style="width: 30px; height: 30px; margin-right: 5px;">
            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="notificacoesDropdown" style="width: 250px;">

                <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('notification-component')->dom;
} elseif ($_instance->childHasBeenRendered('wcPRUhV')) {
    $componentId = $_instance->getRenderedChildComponentId('wcPRUhV');
    $componentTag = $_instance->getRenderedChildComponentTagName('wcPRUhV');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('wcPRUhV');
} else {
    $response = \Livewire\Livewire::mount('notification-component');
    $dom = $response->dom;
    $_instance->logRenderedChild('wcPRUhV', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>
            </div>
        </li>
        <li class="nav-item dropdown">
            <a class="nav-link" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="rounded-circle bg-primary text-white" style="width: 30px; height: 30px; font-size: 15px; margin-right: 5px; display: inline-block; text-align: center; line-height: 30px;">
                    <strong><?php echo e(Auth::user()->initials); ?></strong>
                </span>
            </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" href="<?php echo e(route('users.edit', ['user' => Auth::user()])); ?>">Perfil</a>
                    <a class="dropdown-item" href="#"
                        onclick="event.preventDefault(); localStorage.clear(); document.getElementById('logout-form').submit();">Sair</a>
                </div>
            </li>
        </ul>
    </div>
    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
        <?php echo csrf_field(); ?>

    </form>
</nav>
<?php echo \Livewire\Livewire::scripts(); ?>

<script>
    window.livewire.on('redirectToTicket', ticketId => {
        window.location.href = '/tickets/' + ticketId;
    });
</script>
<?php /**PATH C:\Users\kreot\source\repos\AtecGestPro2\Laravel\resources\views/master/header.blade.php ENDPATH**/ ?>