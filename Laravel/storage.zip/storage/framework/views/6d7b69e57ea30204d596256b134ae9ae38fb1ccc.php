<div>
    <?php if($notifications->isNotEmpty()): ?>
        <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notificationUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="notification-item <?php echo e($notificationUser->isRead ? 'read' : 'unread'); ?> my-2 mx-2">
                <?php if($notificationUser->isRead): ?>
                    <img src="<?php echo e(asset('assets/bell.svg')); ?>" alt="Read Notification">
                <?php else: ?>
                    <img src="<?php echo e(asset('assets/bell2.svg')); ?>" alt="Unread Notification">
                <?php endif; ?>
                <a href="<?php echo e(route('tickets.show', $notificationUser->notification->object_id)); ?>"
                   wire:click.prevent="markAsRead(<?php echo e($notificationUser->id); ?>, <?php echo e($notificationUser->notification->object_id); ?>)">
                    <?php echo e($notificationUser->notification->description); ?>

                </a>
                <button wire:click.prevent="deleteNotification(<?php echo e($notificationUser->id); ?>)" class="delete-btn">X</button>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <p class="ml-3">Não há notificações</p>
    <?php endif; ?>
</div>
<?php /**PATH C:\Users\kreot\source\repos\AtecGestPro2\Laravel\resources\views/livewire/notification-component.blade.php ENDPATH**/ ?>