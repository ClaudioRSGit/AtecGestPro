

<?php $__env->startSection('content'); ?>
    <div class="w-100">

        <?php if(session('success')): ?>
            <div class="alert alert-success" id="success-alert">
                <?php echo e(session('success')); ?>

            </div>

            <script>
                setTimeout(function () {
                    $('#success-alert').fadeOut('slow');
                }, 3000);
            </script>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger" id="error-alert">
                <?php echo e(session('error')); ?>

            </div>

            <script>
                setTimeout(function () {
                    $('#error-alert').fadeOut('slow');
                }, 3000);
            </script>
        <?php endif; ?>

        <h1 class="mb-4">Utilizadores</h1>

        <ul class="nav nav-tabs mb-3" id="userTabs">
            <li class="nav-item">
                <a class="nav-link active" data-toggle="tab" href="#allTable">Todos</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#recycleTable">Reciclagem</a>
            </li>
        </ul>

        <div class="tab-content">

            <div class="tab-pane fade show active" id="allTable">
                <div class="d-flex justify-content-between mb-3">

                    <form action="<?php echo e(route('users.index')); ?>" method="GET">
                        <div class="input-group pr-2">
                            <div class="search-container">
                                <input type="text" name="searchName" class="form-control"
                                       placeholder="<?php echo e(request('searchName') ? request('searchName') : 'Procurar...'); ?>">
                            </div>
                            <div class="input-group-append">
                                <button type="submit" class="btn btn-outline-secondary">
                                    Procurar
                                </button>
                            </div>
                        </div>
                    </form>

                    <div class="buttons">
                        <button class="btn btn-danger" id="delete-selected">Excluir Selecionados</button>
                        <form action="<?php echo e(route('users.index')); ?>" method="GET" id="roleFilterForm">
                            <div>
                                <select class="form-control" id="roleFilter" name="roleFilter" onchange="submitForm()">
                                    <option value="" <?php echo e(request('roleFilter') === '' ? 'selected' : ''); ?>>Todas as
                                        Funções
                                    </option>
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option
                                            value="<?php echo e($role->id); ?>" <?php echo e(request('roleFilter') == $role->id ? 'selected' : ''); ?>><?php echo e($role->description); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </form>
                        <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary">
                            <img src="<?php echo e(asset('assets/new.svg')); ?>">
                            Novo Utilizador
                        </a>
                    </div>
                </div>

                <table class="table" id="userTable">
                    <thead>
                    <tr>
                        <th scope="col">
                            <input type="checkbox" id="select-all">
                        </th>
                        <th><a href="<?php echo e(route('users.index', ['sortColumn' => 'name', 'sortDirection' => $sortColumn === 'name' ?
                ($sortDirection === 'asc' ? 'desc' : 'asc') : 'asc'])); ?>">Nome</a></th>
                        <th><a href="<?php echo e(route('users.index', ['sortColumn' => 'username', 'sortDirection' => $sortColumn === 'username' ?
                ($sortDirection === 'asc' ? 'desc' : 'asc') : 'asc'])); ?>">Username</a></th>
                        <th scope="col">Email</th>
                        <th scope="col">Função</th>
                        <th scope="col">Ativo</th>
                        <th scope="col">Ações</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr class="filler"></tr>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="user-row customTableStyling" data-position="<?php echo e(strtolower($user)); ?>"
                            data-role="<?php echo e($user->role_id); ?>"
                            onclick="location.href='<?php echo e(route('users.show', $user->id)); ?>'">
                            <td>
                                <input type="checkbox" class="no-propagate" name="selectedUsers[]"
                                       value="<?php echo e($user->id); ?>">
                            </td>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->username); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td>
                                <?php echo e($user->role->description); ?>

                            </td>

                            <td><?php echo e($user->isActive == 1 ? 'Sim' : 'Não'); ?></td>
                            <td class="editDelete">
                                <div style="width: 40%">
                                    <a href="<?php echo e(route('users.edit', $user->id)); ?>">
                                        <svg xmlns="http://www.w3.org/2000/svg" height="16" width="16"
                                             viewBox="0 0 512 512">
                                            <path fill="#116fdc"
                                                  d="M471.6 21.7c-21.9-21.9-57.3-21.9-79.2 0L362.3 51.7l97.9 97.9 30.1-30.1c21.9-21.9 21.9-57.3 0-79.2L471.6 21.7zm-299.2 220c-6.1 6.1-10.8 13.6-13.5 21.9l-29.6 88.8c-2.9 8.6-.6 18.1 5.8 24.6s15.9 8.7 24.6 5.8l88.8-29.6c8.2-2.7 15.7-7.4 21.9-13.5L437.7 172.3 339.7 74.3 172.4 241.7zM96 64C43 64 0 107 0 160V416c0 53 43 96 96 96H352c53 0 96-43 96-96V320c0-17.7-14.3-32-32-32s-32 14.3-32 32v96c0 17.7-14.3 32-32 32H96c-17.7 0-32-14.3-32-32V160c0-17.7 14.3-32 32-32h96c17.7 0 32-14.3 32-32s-14.3-32-32-32H96z"/>
                                        </svg>
                                    </a>
                                </div>
                                <div style="width: 40%">
                                    <form method="post" action="<?php echo e(route('users.destroy', $user->id)); ?>"
                                          style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="submit"
                                                onclick="return confirm('Tem certeza que deseja excluir?')"
                                                style="border: none; background: none; padding: 0; margin: 0; cursor: pointer;">
                                            <svg xmlns="http://www.w3.org/2000/svg" height="16" width="16"
                                                 viewBox="0 0 512 512">
                                                <path fill="#116fdc"
                                                      d="M135.2 17.7C140.6 6.8 151.7 0 163.8 0H284.2c12.1 0 23.2 6.8 28.6 17.7L320 32h96c17.7 0 32 14.3 32 32s-14.3 32-32 32H32C14.3 96 0 81.7 0 64S14.3 32 32 32h96l7.2-14.3zM32 128H416V448c0 35.3-28.7 64-64 64H96c-35.3 0-64-28.7-64-64V128zm96 64c-8.8 0-16 7.2-16 16V432c0 8.8 7.2 16 16 16s16-7.2 16-16V208c0-8.8-7.2-16-16-16zm96 0c-8.8 0-16 7.2-16 16V432c0 8.8 7.2 16 16 16s16-7.2 16-16V208c0-8.8-7.2-16-16-16zm96 0c-8.8 0-16 7.2-16 16V432c0 8.8 7.2 16 16 16s16-7.2 16-16V208c0-8.8-7.2-16-16-16z"/>
                                            </svg>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <tr class="filler" style="background-color: #f8fafc"></tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo e($users->appends(request()->input())->links()); ?>


                <div class="container">
                    <form action="<?php echo e(route('import-excel.importUsers')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="file">Excel - Importar Utilizadores</label><br>
                            <input type="file" name="file" id="file" class="btn" text="Escolher ficheiro">
                        </div>
                        <button type="submit" class="btn btn-primary">Importar</button>
                    </form>
                </div>
            </div>
            <div class="tab-pane fade " id="recycleTable">

                <?php if($deletedUsers->isEmpty()): ?>
                    <img src="<?php echo e(asset('assets/reciclagem_azul_extra_bold_2_sem fundo.png')); ?>" alt="Não existem registos" class="bin">
                <?php else: ?>

                <div class="">
                    <table class="table">
                        <thead>
                        <tr>

                            <th scope="col">Nome</th>
                            <th scope="col">Username</th>
                            <th scope="col">Email</th>
                            <th scope="col">Restaurar</th>
                            <th scope="col">Apagar</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr class="filler"></tr>
                        <?php $__currentLoopData = $deletedUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deletedUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="user-row customTableStyling" data-position="" data-role="" onclick="">
                                <td><?php echo e($deletedUser->name); ?></td>
                                <td><?php echo e($deletedUser->username); ?></td>
                                <td><?php echo e($deletedUser->email); ?></td>


                                <td class="editDelete">

                                        <form method="post" action="<?php echo e(route('users.restore', $deletedUser->id)); ?>"
                                              style="display:inline;">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit"
                                                    onclick="return confirm('Tem a certeza que pretende restaurar o utilizador?')"
                                                    style="border: none; background: none; padding: 0; margin: 0; cursor: pointer;">
                                                <img src="<?php echo e(asset('assets/restore.svg')); ?>">
                                            </button>
                                        </form>
                                </td>

                                <td>
                                        <form method="post" action="<?php echo e(route('users.forceDelete', $deletedUser->id)); ?>"
                                              style="display:inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                            <button type="submit"
                                                    onclick="return confirm('Tem certeza que deseja excluir permanentemente?')"
                                                    style="border: none; background: none; padding: 0; margin: 0; cursor: pointer;">
                                                <img src="<?php echo e(asset('assets/permaDelete.svg')); ?>" alt="Delete">

                                            </button>
                                        </form>
                                </td>

                            </tr>
                            <tr class="filler" style="background-color: #f8fafc"></tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($deletedUsers->appends(request()->input())->links()); ?>

                </div>
                <?php endif; ?>

            </div>

        </div>
    </div>

    <style>
        .bin{
            margin-top: 100px!important;
            width: 200px;
            height: 200px;
            display: block;
            margin-left: auto;
            margin-right: auto;
        }
    </style>

    <script>
        $(document).ready(function () {
            function determineContext() {
                return 'pagination';
            }

            function getFragment() {
                return window.location.hash.substring(1);
            }

            function setFragment(fragment) {
                history.pushState(null, null, '#' + fragment);
            }

            function setActiveTab(tabId) {
                $(`#userTabs a[href="#${tabId}"]`).tab('show');
            }

            const activeTabInfo = localStorage.getItem('activeTabInfo');

            if (activeTabInfo) {
                const {tabId, context} = JSON.parse(activeTabInfo);
                setActiveTab(tabId);
                setFragment(tabId);
            }

            $('#userTabs a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
                const tabId = $(e.target).attr('href').substring(1);
                const context = determineContext();

                const activeTabInfo = JSON.stringify({tabId, context});
                localStorage.setItem('activeTabInfo', activeTabInfo);

                setFragment(tabId);
            });

            window.addEventListener('hashchange', function () {
                const fragment = getFragment();
                setActiveTab(fragment);
            });
        });
    </script>


    <script>
        //logica filtro
        function submitForm() {
            // let roleFilterValue = document.getElementById("roleFilter").value;

            document.getElementById("roleFilterForm").submit();
        }
    </script>

    <script>

        document.addEventListener('DOMContentLoaded', function () {
            const deleteSelectedButton = document.getElementById('delete-selected');
            const userCheckboxes = document.getElementsByName('selectedUsers[]');
            const selectAllCheckbox = document.getElementById('select-all');

            deleteSelectedButton.addEventListener('click', function (event) {
                event.stopPropagation();
                massDeleteUsers();
            });

            selectAllCheckbox.addEventListener('change', function () {
                userCheckboxes.forEach(checkbox => {
                    checkbox.checked = selectAllCheckbox.checked;
                });
            });

            userCheckboxes.forEach(checkbox => {
                checkbox.addEventListener('click', function (event) {
                    event.stopPropagation();
                });
            });

            function massDeleteUsers() {
                let userIds = [];
                userCheckboxes.forEach(checkbox => {
                    if (checkbox.checked) {
                        userIds.push(checkbox.value);
                    }
                });

                if (userIds.length > 0) {
                    if (confirm('Tem certeza que deseja excluir os utilizadores selecionados?')) {
                        let form = document.createElement('form');
                        form.action = '<?php echo e(route('users.massDelete')); ?>';
                        form.method = 'post';
                        form.style.display = 'none';

                        let inputToken = document.createElement('input');
                        inputToken.type = 'hidden';
                        inputToken.name = '_token';
                        inputToken.value = '<?php echo e(csrf_token()); ?>';
                        form.appendChild(inputToken);

                        userIds.forEach(userId => {
                            let inputUser = document.createElement('input');
                            inputUser.type = 'hidden';
                            inputUser.name = 'user_ids[]';
                            inputUser.value = userId;
                            form.appendChild(inputUser);
                        });

                        document.body.appendChild(form);
                        form.submit();
                    }
                } else {
                    alert('Selecione pelo menos um utilizador para excluir.');
                }
            }
        });

    </script>


    <script>
        document.addEventListener('DOMContentLoaded', function () {
             let checkboxes = document.querySelectorAll('.no-propagate');

            checkboxes.forEach(function (checkbox) {
                checkbox.addEventListener('click', function (event) {
                    event.stopPropagation();
                });
            });
        });


    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kreot\source\repos\AtecGestPro2\Laravel\resources\views/users/index.blade.php ENDPATH**/ ?>