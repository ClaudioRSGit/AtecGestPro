

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <link rel="stylesheet" type="text/css" href="https://npmcdn.com/flatpickr/dist/themes/material_blue.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <style>
        .flatpickr {
            width: 308px;
        }



    </style>

    <div class="container">

        <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger success-alert"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger success-alert"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <h1>Editar formação</h1>

        <form method="post" action="<?php echo e(route('external.update', $partner_Training_Users->id)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>

            <div class="grid">

                <div class="training">
                    <label for="training_id">Formação:</label>
                    <select class="form-control" id="training_id" name="training_id" required>
                        <?php $__currentLoopData = $trainings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $training): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($training->id); ?>" <?php echo e($training->id == $partner_Training_Users->training_id ? 'selected' : ''); ?>>
                            <?php echo e($training->name); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="partner">
                    <label for="partner_id">Parceiro:</label>
                    <select class="form-control" id="partner_id" name="partner_id" required>
                        <?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($partner->id); ?>" <?php echo e($partner->id == $partner_Training_Users->partner_id ? 'selected' : ''); ?> data-address="<?php echo e($partner->address); ?>">
                            <?php echo e($partner->name); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="technician">
                    <label for="user_id">Técnico:</label>
                    <select class="form-control" id="user_id" name="user_id" required>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($user->role_id == 4 ): ?>
                        <option value="<?php echo e($user->id); ?>" <?php echo e($user->id == $partner_Training_Users->user_id ? 'selected' : ''); ?>>
                            <?php echo e($user->name); ?>

                        </option>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="address">
                    <label for="">Morada:</label>
                    <input type="text" class="form-control" id="address" name="address" disabled>
                </div>

                <div class="startCalendar">
                    <label for="start_date">Data de Início:</label>
                    <input type="datetime-local" class="form-control flatpickr" id="start_date" name="start_date" value="<?php echo e(date('Y-m-d\TH:i:s', strtotime($partner_Training_Users->start_date))); ?>" required>
                </div>

                <div class="endCalendar">
                    <label for="end_date">Data de Fim:</label>
                    <input type="text" class="form-control flatpickr" id="end_date" name="end_date" value="<?php echo e(date('Y-m-d\TH:i:s', strtotime($partner_Training_Users->end_date))); ?>" required>
                </div>

                <div class="materials">
                    <table class="table bg-white">
                        <thead>
                            <tr>
                                <th>Nome</th>
                                <th>Descrição</th>
                                <th>Quantidade</th>
                                <th>Selecionar</th>
                            </tr>
                        </thead>
                        <tbody class="customTableStyling">
                            <tr class="filler"></tr>
                            <?php $__currentLoopData = $partner_Training_Users->materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($material->name); ?></td>
                                    <td><?php echo e($material->description); ?></td>
                                    <td class="pl-4">
                                        <input type="number" name="material_quantities[<?php echo e($material->id); ?>]" value="<?php echo e($material->pivot->quantity ?? 1); ?>" min="0" max="<?php echo e($material->quantity + $material->pivot->quantity); ?>"  >
                                    </td>
                                    <td class="pl-5">
                                        <input type="checkbox" name="materials[<?php echo e($material->id); ?>]" value="<?php echo e($material->id); ?>" <?php echo e($material->pivot->quantity > 0 ? 'checked' : ''); ?> >
                                    </td>
                                </tr>
                                <tr class="filler"></tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if (! ($partner_Training_Users->materials->contains($material))): ?>
                                    <tr>
                                        <td><?php echo e($material->name); ?></td>
                                        <td><?php echo e($material->description); ?></td>
                                        <td class="pl-4">
                                            <input type="number" name="material_quantities[<?php echo e($material->id); ?>]" value="0" min="0" max="<?php echo e($material->quantity); ?>">
                                        </td>
                                        <td class="pl-5">
                                            <input type="checkbox" name="materials[<?php echo e($material->id); ?>]" value="<?php echo e($material->id); ?>">
                                        </td>
                                    </tr>
                                    <tr class="filler"></tr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>



                    </table>
                </div>

                <div class="btns">
                    <button type="submit" class="btn btn-primary">Atualizar formação</button>
                    <a href="<?php echo e(route('external.index')); ?>" class="btn btn-secondary">Cancelar</a>
                </div>
            </div>
        </form>
    </div>


        <?php $__env->stopSection(); ?>

    <style>
        .form-control[readonly] {
            opacity: 0 !important;
            height: 0;
            padding: 0;
        }

        .grid {
            display: grid;
            grid-template-areas:
                'training partner startCalendar'
                'technician address startCalendar'
                'materials materials endCalendar'
                'materials materials endCalendar'
                '. buttons .';
            place-items: center;
            grid-gap: 1rem;
        }
        .grid > div{
            width: 100%;
        }
        .partner {
            grid-area: partner;
        }
        .training {
            grid-area: training;
        }
        .technician {
            grid-area: technician;
        }
        .address {
            grid-area: address;
        }
        .materials {
            grid-area: materials;
            align-self: start;
            display: flex;
            max-height: 20rem;
            overflow: scroll;
        }
        .materials::-webkit-scrollbar {
            display: none;
        }
        .materials thead{
            position: sticky;
            top: 0;
            z-index: 1;
            opacity: 1;
            background-color: #f8fafc;
        }


        .startCalendar {
            grid-area: startCalendar;
        }
        .startCalendar input {
            margin: auto;
        }
        .endCalendar {
            grid-area: endCalendar;
        }
        .btns {
            grid-area: buttons;
        }
    </style>

<?php $__env->startSection('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="https://npmcdn.com/flatpickr/dist/l10n/pt.js"></script>

    <script>
        jQuery(function () {
            flatpickr("#start_date, #end_date", {
                inline: true,
                altInput: true,
                altFormat: "F j, Y",
                dateFormat: "Y-m-d",
                minDate: "today",
                locale: "pt"
            });
        });

        document.addEventListener('DOMContentLoaded', function() {
            var partnerDropdown = document.getElementById('partner_id');
            var addressField = document.getElementById('address');

            function setAddress() {
                var selectedOption = partnerDropdown.options[partnerDropdown.selectedIndex];
                addressField.value = selectedOption.getAttribute('data-address');
            }

            setAddress();

            partnerDropdown.addEventListener('change', setAddress);
        });

        window.setTimeout(function () {
            $(".success-alert").fadeTo(500, 0).slideUp(500, function () {
                $(this).remove();
            });
        }, 2500);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kreot\source\repos\AtecGestPro2\Laravel\resources\views/external/edit.blade.php ENDPATH**/ ?>